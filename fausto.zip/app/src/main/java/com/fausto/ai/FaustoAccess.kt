package com.fausto.ai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.view.Display
import android.view.accessibility.AccessibilityEvent

class FaustoAccess : AccessibilityService() {
    companion object {
        @Volatile var instance: FaustoAccess? = null
    }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }

    fun screenshot(cb: (Bitmap?) -> Unit) {
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                result.hardwareBuffer.close()
                cb(bmp)
            }
            override fun onFailure(errorCode: Int) { cb(null) }
        })
    }

    fun tap(x: Float, y: Float, ms: Long, cb: (Boolean) -> Unit) {
        val p = Path().apply { moveTo(x, y) }
        gesture(p, ms, cb)
    }

    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long, cb: (Boolean) -> Unit) {
        val p = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        gesture(p, ms, cb)
    }

    private fun gesture(p: Path, ms: Long, cb: (Boolean) -> Unit) {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, ms))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { cb(true) }
            override fun onCancelled(d: GestureDescription?) { cb(false) }
        }, null)
        if (!ok) cb(false)
    }
}
