package com.fausto.ai

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ToolResult(val text: String, val imageB64: String? = null)

interface Tools {
    fun runTool(name: String, input: JSONObject): ToolResult
}

class Brain(private val ctx: Context, private val tools: Tools) {
    private val prefs = ctx.getSharedPreferences("fausto", Context.MODE_PRIVATE)
    private val history = ArrayList<JSONObject>()
    private val defaultModels = listOf("gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash")
    @Volatile private var okModel = 0

    private fun system(): String {
        val date = SimpleDateFormat("d MMMM yyyy EEEE HH:mm", Locale("tr", "TR")).format(Date())
        val mem = prefs.getString("memory", "").orEmpty()
        return "Sen Fausto'sun: kullanıcının Android telefonunda yaşayan, Jarvis gibi çok zeki bir sesli asistan. " +
            "Ana dilin Türkçe; kullanıcı başka dilde konuşursa o dilde cevap ver. " +
            "Cevapların sesli okunacak: kısa, doğal ve net ol; markdown, emoji ve kod bloğu kullanma. " +
            "Kod, HTML, C++ gibi uzun içerikleri asla sesli okuma: create_file ile telefona kaydet, sadece ne yaptığını söyle. " +
            "Kod yazarken sözdizimi hatası yapma, yazdıktan sonra tekrar kontrol et. " +
            "Ekranda ne olduğunu görmen gerekirse (oyun taktiği, 'bu ne', çeviri) look_at_screen kullan. " +
            "Kullanıcı açıkça isterse tap, swipe, press_key ile telefonu kullanabilirsin; her adımdan sonra look_at_screen ile sonucu kontrol et. " +
            "Birkaç denemede olmuyorsa vazgeç ve dürüstçe söyle. " +
            "Mesaj gönderme, silme, satın alma, ödeme gibi geri alınamaz işlerde önce kullanıcıdan onay iste. " +
            "Resim veya video üretemezsin, istenirse dürüstçe söyle. " +
            "Kullanıcı bir şeyi hatırlamanı isterse remember kullan. " +
            "Şu an: $date. Hatırladıkların: $mem"
    }

    private fun prop(type: String, d: String) = JSONObject().put("type", type).put("description", d)

    private fun fn(name: String, desc: String, props: JSONObject?, req: List<String>): JSONObject {
        val o = JSONObject().put("name", name).put("description", desc)
        if (props != null) {
            val params = JSONObject().put("type", "OBJECT").put("properties", props)
            if (req.isNotEmpty()) params.put("required", JSONArray(req))
            o.put("parameters", params)
        }
        return o
    }

    private fun toolsJson(): JSONArray {
        val d = JSONArray()
        d.put(fn("look_at_screen", "Telefon ekranının anlık görüntüsünü alır ve sana gösterir.", null, listOf()))
        d.put(fn("tap", "Ekrana dokunur veya basılı tutar. Koordinatlar look_at_screen görüntüsüne göredir.",
            JSONObject().put("x", prop("NUMBER", "x koordinatı")).put("y", prop("NUMBER", "y koordinatı"))
                .put("duration_ms", prop("NUMBER", "basılı tutma süresi ms, varsayılan 60")),
            listOf("x", "y")))
        d.put(fn("swipe", "Ekranda bir noktadan diğerine kaydırır.",
            JSONObject().put("x1", prop("NUMBER", "başlangıç x")).put("y1", prop("NUMBER", "başlangıç y"))
                .put("x2", prop("NUMBER", "bitiş x")).put("y2", prop("NUMBER", "bitiş y"))
                .put("duration_ms", prop("NUMBER", "süre ms, varsayılan 300")),
            listOf("x1", "y1", "x2", "y2")))
        d.put(fn("press_key", "Geri, ana ekran veya son uygulamalar tuşuna basar.",
            JSONObject().put("key", prop("STRING", "back, home veya recents").put("enum", JSONArray(listOf("back", "home", "recents")))),
            listOf("key")))
        d.put(fn("open_app", "Telefondaki bir uygulamayı adıyla açar.",
            JSONObject().put("name", prop("STRING", "uygulama adı")), listOf("name")))
        d.put(fn("create_file", "Telefonun İndirilenler/Fausto klasörüne bir dosya kaydeder (kod, metin, html vb).",
            JSONObject().put("filename", prop("STRING", "uzantılı dosya adı, örn. oyun.cpp"))
                .put("content", prop("STRING", "dosyanın tam içeriği")),
            listOf("filename", "content")))
        d.put(fn("set_alarm", "Telefona alarm kurar.",
            JSONObject().put("hour", prop("NUMBER", "saat 0-23")).put("minute", prop("NUMBER", "dakika 0-59"))
                .put("label", prop("STRING", "alarm adı")),
            listOf("hour", "minute")))
        d.put(fn("remember", "Kullanıcı hakkında kalıcı bir bilgiyi hatırlar.",
            JSONObject().put("note", prop("STRING", "hatırlanacak not")), listOf("note")))
        return JSONArray().put(JSONObject().put("functionDeclarations", d))
    }

    private fun post(model: String, body: JSONObject, key: String): Pair<Int, String> {
        val u = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val c = URL(u).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.setRequestProperty("x-goog-api-key", key)
        c.setRequestProperty("content-type", "application/json")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val txt = stream?.bufferedReader()?.use { it.readText() } ?: ""
        return Pair(code, txt)
    }

    private fun errMsg(txt: String): String = try {
        JSONObject(txt).getJSONObject("error").getString("message")
    } catch (e: Exception) { txt.take(200) }

    private fun pruneImages(contents: JSONArray) {
        for (i in 0 until contents.length() - 1) {
            val parts = contents.getJSONObject(i).optJSONArray("parts") ?: continue
            for (j in 0 until parts.length()) {
                val p = parts.optJSONObject(j) ?: continue
                if (p.has("inlineData")) parts.put(j, JSONObject().put("text", "[eski ekran görüntüsü kaldırıldı]"))
            }
        }
    }

    private fun textMsg(role: String, text: String) =
        JSONObject().put("role", role).put("parts", JSONArray().put(JSONObject().put("text", text)))

    fun ask(text: String, cancelled: () -> Boolean, onStatus: (String) -> Unit): String {
        val key = prefs.getString("gemini_key", "").orEmpty().trim()
        if (key.isEmpty()) return "Gemini API anahtarı girilmemiş. Uygulamayı açıp anahtarı yaz."
        val custom = prefs.getString("model", "").orEmpty().trim()
        val models = if (custom.isNotEmpty()) listOf(custom) else defaultModels
        var mi = if (custom.isEmpty()) okModel.coerceIn(0, models.size - 1) else 0

        val contents = JSONArray()
        synchronized(history) { history.forEach { contents.put(it) } }
        contents.put(textMsg("user", text))

        var steps = 0
        var retries = 0
        var finalText = ""
        while (steps < 25) {
            if (cancelled()) return ""
            pruneImages(contents)
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system()))))
                .put("contents", contents)
                .put("tools", toolsJson())
                .put("generationConfig", JSONObject().put("maxOutputTokens", 2000))
            val (code, txt) = post(models[mi], body, key)
            if (code == 404 && mi < models.size - 1) { mi++; continue }
            if (code == 429 && retries < 2) { retries++; Thread.sleep(5000); continue }
            if (code != 200) {
                return when (code) {
                    400 -> if (txt.contains("API key", true)) "API anahtarı yanlış görünüyor." else "Gemini hatası (400): " + errMsg(txt)
                    429 -> "Ücretsiz kullanım sınırına ulaştın. Biraz bekleyip tekrar dene."
                    else -> "Gemini hatası ($code): " + errMsg(txt)
                }
            }
            if (custom.isEmpty()) okModel = mi
            val resp = JSONObject(txt)
            val cand = resp.optJSONArray("candidates")?.optJSONObject(0)
            val content = cand?.optJSONObject("content")
            val parts = content?.optJSONArray("parts")
            if (content == null || parts == null) {
                return "Cevap alınamadı (" + (cand?.optString("finishReason") ?: "engellendi") + ")."
            }
            content.put("role", "model")
            contents.put(content)

            val sb = StringBuilder()
            val calls = ArrayList<JSONObject>()
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.has("functionCall")) calls.add(p.getJSONObject("functionCall"))
                else if (p.has("text") && !p.optBoolean("thought", false)) sb.append(p.getString("text"))
            }
            if (calls.isNotEmpty()) {
                val respParts = JSONArray()
                var img: String? = null
                for (c in calls) {
                    val name = c.getString("name")
                    onStatus("• $name")
                    val r = try {
                        tools.runTool(name, c.optJSONObject("args") ?: JSONObject())
                    } catch (e: Exception) { ToolResult("Hata: ${e.message}") }
                    respParts.put(JSONObject().put("functionResponse",
                        JSONObject().put("name", name).put("response", JSONObject().put("result", r.text))))
                    if (r.imageB64 != null) img = r.imageB64
                }
                if (img != null) {
                    respParts.put(JSONObject().put("text", "Ekran görüntüsü:"))
                    respParts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", img)))
                }
                contents.put(JSONObject().put("role", "user").put("parts", respParts))
                steps++
                continue
            }
            finalText = sb.toString().trim()
            break
        }
        if (cancelled()) return ""
        if (finalText.isEmpty()) finalText = if (steps >= 25) "Çok adım attım, durdum." else "Tamam."
        synchronized(history) {
            history.add(textMsg("user", text))
            history.add(textMsg("model", finalText))
            while (history.size > 16) history.removeAt(0)
        }
        return finalText
    }
}
